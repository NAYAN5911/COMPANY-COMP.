# How to Use

## ROC calendar
Enter the FY end and AGM date in the yellow cells. Due dates, and the status of each task (Pending / Overdue / On time / Filed late), update automatically. Record the actual filing date in column F. Add other forms in the blank rows.

## Board meeting tracker
List meetings in order. The tracker flags gaps above 120 days, notice shorter than 7 days and meetings without quorum. Adjust the quorum input per meeting.

## Director and KMP register
Maintain one row per director/KMP; the limit check compares other directorships against 20 total / 10 public.

## Publishing on GitHub
```
git init
git add .
git commit -m "Initial commit: company law and ROC compliance templates"
git branch -M main
git remote add origin https://github.com/<your-username>/company-law-roc-templates.git
git push -u origin main
```
