# Director Appointment Checklist

- [ ] DIN and valid DIR-3 KYC of proposed director
- [ ] Consent to act (DIR-2) and declaration of non-disqualification (DIR-8)
- [ ] Disclosure of interest (MBP-1) and other directorships within limits (20; 10 for public companies)
- [ ] Eligibility under Section 164 (disqualifications) confirmed
- [ ] Articles of Association permit appointment; maximum number of directors not exceeded
- [ ] Board resolution passed (additional director) / general meeting resolution (regular director)
- [ ] Independent director: declaration of independence, registration in databank, proficiency test where required
- [ ] Managing/whole-time director: Schedule V and Section 196/197 conditions, shareholder approval
- [ ] Appointment letter issued
- [ ] Form DIR-12 filed within the prescribed time; registers updated
