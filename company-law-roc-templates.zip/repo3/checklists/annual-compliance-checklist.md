# Annual ROC Compliance Checklist

**Company:** ____  **CIN:** ____  **FY:** ____

## Board and governance
- [ ] Minimum four board meetings, gap between two meetings not above 120 days
- [ ] Committees constituted and meeting where applicable (audit, NRC, CSR)
- [ ] Declarations received: MBP-1, DIR-8, independent director declarations
- [ ] Directors' report prepared with all required disclosures
- [ ] Auditor appointed or reappointed; consent and eligibility certificate received

## Filings
- [ ] AGM held in time; notice sent with required clear days
- [ ] ADT-1 (auditor appointment)
- [ ] AOC-4 (financial statements)
- [ ] MGT-7 / MGT-7A (annual return)
- [ ] DPT-3 (deposits / outstanding receipts)
- [ ] MSME-1 (half-yearly), where applicable
- [ ] DIR-3 KYC for each director
- [ ] Event-based forms: DIR-12, PAS-3, SH-7, CHG-1 and others as applicable

## Records
- [ ] Statutory registers updated (members, directors, charges, contracts, loans/investments)
- [ ] Minutes books signed; attendance registers maintained
- [ ] Beneficial ownership (BEN-2 / SBO) checks and register of significant beneficial owners
