# Company Incorporation Checklist

- [ ] Name availability and reservation
- [ ] DSC and DIN for subscribers/directors
- [ ] Memorandum and Articles of Association drafted
- [ ] Registered office proof and NOC from owner
- [ ] SPICe+ filing with linked PAN, TAN, GST, EPFO and ESIC options as applicable
- [ ] Certificate of Incorporation received
- [ ] INC-20A commencement of business filed within the time limit
- [ ] First board meeting held; first auditor appointed
- [ ] Bank account opened; share capital deposited
- [ ] Share certificates issued; registers created
