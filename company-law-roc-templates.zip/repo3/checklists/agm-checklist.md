# AGM Checklist

- [ ] Board meeting approves financial statements, directors' report, and AGM notice and date
- [ ] Record date / book closure (if any) fixed
- [ ] Notice dispatched to members, directors and auditors with at least 21 clear days (or shorter notice with required consent)
- [ ] Notice contents: day, date, time, venue, agenda, explanatory statement for special business, proxy and attendance slip
- [ ] E-voting requirements considered, where applicable
- [ ] Quorum, chairman and proxies verified at the meeting
- [ ] Resolutions passed with required majority (ordinary / special)
- [ ] Minutes prepared and signed within the time prescribed by SS-2
- [ ] Post-AGM filings: ADT-1, AOC-4, MGT-7 within due dates
