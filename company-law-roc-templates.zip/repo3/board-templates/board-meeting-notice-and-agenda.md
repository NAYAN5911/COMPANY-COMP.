# Notice of Board Meeting

**[Company Name]**
CIN: [____]  Registered office: [____]

Date of notice: [____]

To,
All Directors

Notice is hereby given that the [Nth] meeting of the Board of Directors for FY [____] will be held on [day, date] at [time] at [venue / video conference link].

## Agenda
1. Leave of absence
2. Confirmation of minutes of previous meeting
3. Review of financial results and compliance report
4. [Specific item / special business]
5. Any other matter with the permission of the Chairman

By order of the Board
For [Company Name]

[Name], Company Secretary / Director
DIN/Membership no.: [____]
