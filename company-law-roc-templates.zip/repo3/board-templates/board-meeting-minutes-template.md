# Minutes of the [Nth] Meeting of the Board of Directors

**Company:** [____]  **Date:** [____]  **Time:** [start] to [end]  **Venue:** [____]

**Directors present:** [names]
**Leave of absence granted to:** [names]
**In attendance:** [CS / auditors / invitees]

The Chairman took the chair, noted that the quorum was present and called the meeting to order.

1. **Minutes of previous meeting** - Confirmed and signed.
2. **[Agenda item]** - [Discussion in brief and the resolution passed.]
   "RESOLVED THAT ..."
3. **Any other business**

There being no other business, the meeting concluded with a vote of thanks to the Chair.

Date of signing: [____]   Chairman: [signature]
