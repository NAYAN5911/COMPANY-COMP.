# Board Resolution - Appointment of Additional Director

"RESOLVED THAT pursuant to Section 161(1) of the Companies Act, 2013, the Articles of Association of the Company and subject to approval of members in general meeting, Mr./Ms. [Name] (DIN: [____]), who has given consent to act (Form DIR-2) and declaration of non-disqualification (Form DIR-8), be and is hereby appointed as an Additional Director of the Company with effect from [date], to hold office up to the date of the next Annual General Meeting.

RESOLVED FURTHER THAT any Director or the Company Secretary be and is hereby authorised to file Form DIR-12 with the Registrar of Companies and to do all acts necessary to give effect to this resolution."

Certified true copy
For [Company Name]

[Name, Designation, DIN]
Date: [____]  Place: [____]
