# Notice of Annual General Meeting - Outline

**[Company Name]**, CIN [____]

Notice is given that the [Nth] Annual General Meeting of the members will be held on [day, date] at [time] at [venue / VC details].

## Ordinary business
1. Adoption of audited financial statements, directors' report and auditors' report for FY [____]
2. Appointment of director retiring by rotation: [Name]
3. Appointment/reappointment of statutory auditors and fixing remuneration

## Special business
4. [Item] - explanatory statement under Section 102 annexed

## Notes
- Proxy: a member entitled to attend and vote may appoint a proxy; proxy form must be deposited not less than 48 hours before the meeting
- Corporate members: board resolution authorising representative
- E-voting instructions and cut-off date, if applicable
- Route map and attendance slip

By order of the Board
[Name, Company Secretary]  Date: [____]  Place: [____]
